install.packages("xlsx")
install.packages("rJava")
library(randomForest)
library(xlsx)
library(caTools)

data <- read.csv("~/MLprog/data.csv")
head(data)

df = subset(data, select = -c(date, waterfront, view, yr_built, yr_renovated, street, city, statezip, country))

set.seed(95014)
sampleSplit <- sample.split(Y=df$price, SplitRatio=0.8)
training <- subset(x=df, sampleSplit==TRUE)
testing <- subset(x=df, sampleSplit==FALSE)

rf.forest <- randomForest(price ~ .,data = training, importance=TRUE )

rf.forest
plot(rf.forest)

result <- data.frame(testing$price, predict(rf.forest,testing,type = "response"))
result

plot(result)

colnames(result) <- c('Actual', 'Predicted')
result <- as.data.frame(result)

mse <- mean((result$Actual - result$Predicted)^2)
rmse <- sqrt(mse)
rmse

