library(dplyr)
library(ggplot2)
library(caTools)
library(corrgram)

data <- read.csv("~/MLprog/data.csv")
head(data)



any(is.na(data))



df = subset(data, select = -c(date, waterfront, view, yr_built, yr_renovated, street, city, statezip, country))
head(df)
corrgram(df, lower.panel = panel.shade, upper.panel = panel.cor)


set.seed(38)
sampleSplit <- sample.split(Y=df$price, SplitRatio=0.8)
trainset <- subset(x=df, sampleSplit==TRUE)
testSet <- subset(x=df, sampleSplit==FALSE)

model <- lm(formula = price ~ ., data = trainset)
summary(model)

prediction <- predict(model, testSet)

modelEval <- cbind(testSet$price, prediction)
colnames(modelEval) <- c('Actual', 'Predicted')
modelEval <- as.data.frame(modelEval)

plot(modelEval)

mse <- mean((modelEval$Actual - modelEval$Predicted)^2)
rmse <- sqrt(mse)

